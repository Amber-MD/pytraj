CPPTRAJLIB=/c/projects/cpptraj-l282n/lib
SHARED_SUFFIX=.lib 
LIBCPPTRAJ_TARGET=$(CPPTRAJLIB)/libcpptraj$(SHARED_SUFFIX) 
INSTALL_TARGETS= install_cpptraj install_ambpdb 
DBGFLAGS= 
CC=gcc 
CXX=g++ 
FC=gfortran 
CFLAGS=   -O3 -Wall -DHASBZ2 -DHASGZ -DBINTRAJ -D_LARGEFILE_SOURCE -D_FILE_OFFSET_BITS=64 -I/usr/local/include -I/mingw64/include -Ixdrfile $(DBGFLAGS) 
CXXFLAGS= -O3 -Wall -DHASBZ2 -DHASGZ -DBINTRAJ -D_LARGEFILE_SOURCE -D_FILE_OFFSET_BITS=64 -I/usr/local/include -I/mingw64/include -Ixdrfile $(DBGFLAGS) 
FFLAGS=   -O3       -DHASBZ2 -DHASGZ -DBINTRAJ -D_LARGEFILE_SOURCE -D_FILE_OFFSET_BITS=64 -I/usr/local/include -I/mingw64/include -Ixdrfile -ffree-form $(DBGFLAGS) 
READLINE_TARGET=/mingw64/lib/libreadline.a 
READLINE_HOME=/mingw64/include/readline/ 
XDRFILE=xdrfile/libxdrfile.a 
XDRFILE_HOME=xdrfile 
XDRFILE_TARGET=xdrfile/libxdrfile.a 
FFT_DEPEND=pub_fft.o 
FFT_LIB=pub_fft.o 
LDFLAGS=-lreadline -ltermcap -larpack -L/usr/local/lib -lnetcdf -lopenblas -lbz2 -lz xdrfile/libxdrfile.a -lgfortran -lquadmath -w  -static 
SFX= 
EXE=.exe 
